package lexer;
public class Real extends Token {

	private float value;
	public Real(float v) { super(Tag.REAL); value = v; }

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public String toString() { return "" + value; }
}
