package lexer;
import java.io.*; import java.util.*; import symbols.*;
public class Lexer {
   public static int line = 1;
   char peek = ' ';
   Hashtable words = new Hashtable();
   private Integer cur_command_num = 1; // 当前指令编号
   private Integer cur_index = 0;
   private String command = "";
   LinkedHashMap<Integer, String> commands = new LinkedHashMap<>();  // 指令集

   void reserve(Word w) { words.put(w.lexeme, w); }

   public Lexer() {
      // 保留关键字
      reserve( new Word("if",    Tag.IF)    );
      reserve( new Word("else",  Tag.ELSE)  );
      reserve( new Word("while", Tag.WHILE) );
      reserve( new Word("do",    Tag.DO)    );
      reserve( new Word("break", Tag.BREAK) );
      reserve( new Word("iffalse",Tag.IFNOT));  // 新增
      reserve( new Word("goto",  Tag.GOTO  ));  // 新增

      reserve( Word.True );  reserve( Word.False );

      reserve( Type.Int  );  reserve( Type.Char  );
      reserve( Type.Bool );  reserve( Type.Float );
   }
   // 获取待执行的指令
   public void getCommands(){
      Scanner scan = new Scanner(System.in);
      ArrayList<Integer> oldNum = new ArrayList<>();// 刚刚存过的指令编号，用于多行的指令
      while (scan.hasNextLine()) {
         String str = scan.nextLine().trim();
         if (str.equals("")){
            scan.close();
            break;
         }
         str = str.replaceAll("goto L", "goto ");
         String[] tmp = str.split(":");
         int len = tmp.length;
         String first_num = tmp[0].substring(1).trim();  // 该行第一个编号（有指令编号时）
         if(str.endsWith(":")){
            for (Integer old : oldNum){// // 给上一条指令末尾添加goto，明确指令顺序
               commands.replace(old, commands.get(old)+" goto "+first_num);
            }
            commands.put(Integer.parseInt(first_num), null);
            break;
         }else if(len>1){  // 该行有指令编号
            for (Integer old : oldNum){// // 给上一条指令末尾添加goto，明确指令顺序
               commands.replace(old, commands.get(old)+" goto "+first_num);
            }
            oldNum.clear();
            for(int i=0; i<len-1; i++){
               Integer key = Integer.parseInt(tmp[i].substring(1).trim());
               commands.put(key, tmp[len-1].trim());
               oldNum.add(key);
            }
         }else{   // 该行无指令编号，属于前一次的指令
            for(Integer num:oldNum){
               String oldValue = commands.get(num);
               commands.replace(num, oldValue+" "+tmp[0].trim());
            }
         }
      }
      setCommand(cur_command_num);
      commands.forEach((k,v)-> System.out.println(k+" ["+v+"]"));
      System.out.println("Input Finished!!!\n====================");
   }

   // goto到指定的指令
   public void setCommand(Integer command_num){
      this.command = commands.get(command_num);
      this.cur_command_num = command_num;
      this.cur_index = 0;
      this.peek = ' ';
   }

   // 下一条指令
   public void nextCommand(){
      Iterator<Map.Entry<Integer, String>> iterator = commands.entrySet().iterator();
      Map.Entry<Integer, String> next = null;
      while (iterator.hasNext()){
         next = iterator.next();
         if (next.getKey() == cur_command_num && iterator.hasNext()){
            next = iterator.next();break;
         }
      }
      if (next!=null)setCommand(next.getKey());
   }

   void readch() throws IOException {
      if(command==null) {
         peek = '\0';   // 所有指令执行完毕
      }else{
         if(cur_index >= command.length()){
            peek = '\n';return;
         }
         peek = command.charAt(cur_index); cur_index++;
      }
   }
   boolean readch(char c) throws IOException {
      readch();
      if( peek != c ) return false;
      peek = ' ';
      return true;
   }
   // 读取文件中的一个Token(保留关键字、运算符、变量名、括号等)
   public Token scan() throws IOException {
      for( ; ; readch() ) {
         if( peek == ' ' || peek == '\t' ) continue;
         else if( peek == '\n' ) nextCommand();
         else if (peek == '\0') return null; // 所有指令执行完毕
         else break;
      }
      switch( peek ) {
      case '&':
         if( readch('&') ) return Word.and;  else return new Token('&');
      case '|':
         if( readch('|') ) return Word.or;   else return new Token('|');
      case '=':
         if( readch('=') ) return Word.eq;   else return new Token('=');
      case '!':
         if( readch('=') ) return Word.ne;   else return new Token('!');
      case '<':
         if( readch('=') ) return Word.le;   else return new Token('<');
      case '>':
         if( readch('=') ) return Word.ge;   else return new Token('>');
      }
      if( Character.isDigit(peek) ) {
         int v = 0;
         do {
            v = 10*v + Character.digit(peek, 10); readch();
         } while( Character.isDigit(peek) );
         if( peek != '.' ) return new Num(v);
         float x = v; float d = 10;
         for(;;) {
            readch();
            if( ! Character.isDigit(peek) ) break;
            x = x + Character.digit(peek, 10) / d; d = d*10;
         }
         return new Real(x);
      }
      if( Character.isLetter(peek) ) {
         StringBuffer b = new StringBuffer();
         do {
            b.append(peek); readch();
         } while( Character.isLetterOrDigit(peek) );
         String s = b.toString();
         Word w = (Word)words.get(s);
         if( w != null ) return w;  // 是保留关键字or已存在的变量名
         w = new Word(s, Tag.ID);
         words.put(s, w);
         return w;
      } 
      Token tok = new Token(peek); peek = ' ';
      return tok;
   }
}
