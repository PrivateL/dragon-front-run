package lexer;

public class Num extends Token {

	private int value;
	public Num(int v) { super(Tag.NUM); value = v; }

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String toString() { return "" + value; }
}
