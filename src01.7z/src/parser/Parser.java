package parser;
import java.io.*;
import java.util.HashMap;

import lexer.*; import symbols.*; import inter.*;

public class Parser {

   private Lexer lex;    // lexical analyzer for this parser
   private Token look;   // lookahead tagen
   Env top = null;       // current or top symbol table
   int used = 0;         // storage used for declarations
   HashMap<String, Expr> param = new HashMap<>();

   public Parser(Lexer l) throws IOException {
      lex = l; move();
   }

   void move() throws IOException { look = lex.scan();}

   void error(String s) { throw new Error("near line "+lex.line+": "+s); }

   void match(int t) throws IOException {
      if( look.tag == t ) move();
      else error("syntax error");
   }

   public void program() throws IOException {  // program -> block
      // 按顺序开始执行指令
      while (look!=null){
         switch (look.tag){
            case Tag.ID:
               Word w = (Word) look;
               move();
               if(look.tag=='['){   // 数组

               }else if(look.tag == '='){ // 赋值语句
                  move();
                  Expr e = expr();  // 匹配一个算术表达式or常量
                  if(e instanceof Constant){ // 常量
                     Constant constant = (Constant)e;
                     param.put(w.lexeme, constant);
                     System.out.println(w.lexeme + " is " +constant.op);
                  }else if(e instanceof Arith){ //算术表达式
                     Arith arith = (Arith)e;
                     // 保存算术表达式的结果为常量
                     Constant constant;
                     if(arith.getValue().tag == Tag.NUM)
                        constant = new Constant(arith.getValue(), Type.Int);
                     else
                        constant = new Constant(arith.getValue(), Type.Float);

                     param.put(w.lexeme, constant);
                     System.out.println(w.lexeme + " is " +constant.op);
                  }else {  // 关系表达式不会出现在赋值语句中
                     error(e.toString());
                  }
               }
               break;
            case Tag.GOTO:
               move();lex.setCommand(((Num)look).getValue());
               System.out.println("goto command "+look);
               move();break;
            case Tag.IFNOT:  case Tag.IF: // 匹配到 iffalse / if
               boolean isIF = true;
               if (look.tag==Tag.IFNOT) isIF = false;
               // 匹配一个关系表达式
//               System.out.println(look);
               move(); Rel rel = (Rel) equality();
               System.out.println("("+rel.toString() + ") is " + rel.getValue());
               // 表达式的值不是需要的值
               if((!isIF && rel.getValue()) || (isIF && !rel.getValue())){
                  match(Tag.GOTO);match(Tag.NUM);
               }
               break;
         }
      }
       System.out.println("Completed!!!");
//       param.forEach((k, v)-> System.out.println(k + "=" + v.toString()));
   }

   Expr bool() throws IOException {
      Expr x = join();
      while( look.tag == Tag.OR ) {
         Token tok = look;  move();  x = new Or(tok, x, join());
      }
      return x;
   }

   Expr join() throws IOException {
      Expr x = equality();
      while( look.tag == Tag.AND ) {
         Token tok = look;  move();  x = new And(tok, x, equality());
      }
      return x;
   }

   // 等式
   Expr equality() throws IOException {
      Expr x = rel();
      while( look.tag == Tag.EQ || look.tag == Tag.NE ) {
         Token tok = look;  move();  x = new Rel(tok, x, rel());
      }
      return x;
   }

   // 不等式
   Expr rel() throws IOException {
      Expr x = expr();
      switch( look.tag ) {
      case '<': case Tag.LE: case Tag.GE: case '>':
         Token tok = look;  move();  return new Rel(tok, x, expr());
      default:
         return x;
      }
   }

   // 加减运算
   Expr expr() throws IOException {
      Expr x = term();
      while( look.tag == '+' || look.tag == '-' ) {
         Token tok = look;  move();  x = new Arith(tok, x, term());
      }
      return x;
   }

   // 乘除运算
   Expr term() throws IOException {
      Expr x = unary();
      while(look.tag == '*' || look.tag == '/' ) {
         Token tok = look;  move();   x = new Arith(tok, x, unary());
      }
      return x;
   }
   // 单目表达式
   Expr unary() throws IOException {
      if( look.tag == '-' ) {
         move();  return new Unary(Word.minus, unary());
      }
      else if( look.tag == '!' ) {
         Token tok = look;  move();  return new Not(tok, unary());
      }
      else return factor();
   }

   // 单个元素
   Expr factor() throws IOException {
      Expr x = null;
      switch( look.tag ) {
      /*case '(':
         move(); x = bool(); match(')');
         return x;*/
      case Tag.NUM:
         x = new Constant(look, Type.Int);    move(); return x;
      case Tag.REAL:
         x = new Constant(look, Type.Float);  move(); return x;
      case Tag.TRUE:
         x = Constant.True;                   move(); return x;
      case Tag.FALSE:
         x = Constant.False;                  move(); return x;
      case Tag.ID:
         Constant id = (Constant) param.get(((Word)look).lexeme);
         // 处理未初始化的变量，默认为Num类型
         if( id == null ){
            Token tmp = look;
            move();
            if (look.tag != '[') {
               x = new Constant(new Num(0), Type.Int);
               param.put(((Word) tmp).lexeme, x);
               return x;
            }else {
               Constant index;
               match('[');index = (Constant) factor();match(']');
            }
         }
         move();
         if( look.tag != '[' ) return id;
         else return offset(id);// TODO 处理数组
      default:
         error("syntax error");
         return x;
      }
   }

   Access offset(Constant a) throws IOException {   // I -> [E] | [E] I
      Constant i; Expr w; Expr t1, t2; Expr loc;  // inherit id

      Type type = a.type;
      match('['); i = (Constant) factor(); match(']');     // first index, I -> [ E ]
      type = ((Array)type).of;
      w = new Constant(type.width);
      t1 = new Arith(new Token('*'), i, w);
      loc = t1;
      while( look.tag == '[' ) {      // multi-dimensional I -> [ E ] I
         match('['); i = (Constant) factor(); match(']');
         type = ((Array)type).of;
         w = new Constant(type.width);
         t1 = new Arith(new Token('*'), i, w);
         t2 = new Arith(new Token('+'), loc, t1);
         loc = t2;
      }
      return new Access(a, loc, type);
   }
}
