package inter;
import lexer.*; import symbols.*;

// 算术表达式
public class Arith extends Op {

   private Token value;
   public Expr expr1, expr2;

   public Arith(Token tok, Expr x1, Expr x2)  {
      super(tok, null); expr1 = x1; expr2 = x2;
      type = Type.max(expr1.type, expr2.type);
      if (type == null ) error("type error");   // bool类型不参与数值计算，报错
      updateValue();
   }

   // 计算表达式的值
   private void updateValue(){
      float tmp = 0.0f;
      if(expr1.op.tag == Tag.REAL){
         Real t = (Real)(expr1.op);
         tmp += t.getValue();
      }
      else if(expr1.op.tag == Tag.NUM){
         Num t = (Num)(expr1.op);
         tmp += t.getValue();
      }else System.out.println(toString());
      if(expr2.op.tag == Tag.REAL){
         Real t = (Real)(expr1.op);
         if(op.tag == '+') tmp += t.getValue();
         else if(op.tag == '-')tmp -= t.getValue();
         else if(op.tag == '*')tmp *= t.getValue();
         else if(op.tag == '/')tmp /= t.getValue();
      }else if(expr2.op.tag == Tag.NUM){
         Num t = (Num)(expr2.op);
         if(op.tag == '+') tmp += t.getValue();
         else if(op.tag == '-')tmp -= t.getValue();
         else if(op.tag == '*')tmp *= t.getValue();
         else if(op.tag == '/')tmp /= t.getValue();
      }else System.out.println(toString());

      if(type==Type.Int || type==Type.Char)value = new Num((int)tmp);
      else if(type==Type.Float) value = new Real(tmp);
   }

   public Token getValue() {
      return value;
   }

   public Expr gen() {
      return new Arith(op, expr1.reduce(), expr2.reduce());
   }

   public String toString() {
      return expr1.toString()+" "+op.toString()+" "+expr2.toString();
   }
}
