package inter;
import lexer.*; import symbols.*;

// 逻辑表达式
public class Rel extends Logical {

   private boolean value;
   public Rel(Token tok, Expr x1, Expr x2) { super(tok, x1, x2); }

   public Type check(Type p1, Type p2) {
      if ( p1 instanceof Array || p2 instanceof Array ) return null;
      else if( p1 == p2 ) return Type.Bool;
      else return null;
   }

   // 计算表达式的值
   private void updateValue(){
      float left=0, right=0;
      if(expr1.op.tag == Tag.NUM){ Num t = (Num)expr1.op; left = t.getValue(); }
      else { Real t = (Real)expr1.op; left = t.getValue(); }
      if(expr2.op.tag == Tag.NUM){ Num t = (Num)expr2.op; right = t.getValue(); }
      else { Real t = (Real)expr2.op; right = t.getValue(); }

      if(op.tag == Tag.LE) { value = left <= right; }
      else if(op.tag == Tag.GE) { value = left >= right; }
      else if(op.tag == Tag.EQ) { value = left == right; }
      else if(op.tag == Tag.NE) { value = left != right; }
      else if(op.tag == '<') { value = left < right; }
      else if(op.tag == '>') { value = left > right; }
      else {
         error(toString());
      }
   }

   public boolean getValue(){
      return this.value;
   }

   public void jumping(int t, int f) {
      Expr a = expr1.reduce();
      Expr b = expr2.reduce();
      String test = a.toString() + " " + op.toString() + " " + b.toString();
      emitjumps(test, t, f);
   }
}
