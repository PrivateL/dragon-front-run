package inter;
import lexer.*; import symbols.*;

// 变量
public class Id extends Expr {

	public int offset;     // relative address
	private Token value=new Num(0);	// 变量的值

	public Id(Word id, Type p, int b) { super(id, p); offset = b; }

	public Token getValue() {
		return value;
	}
	public void setValue(Token value) {
		this.value = value;
	}
	//	public String toString() {return "" + op.toString() + offset;}
}
