import lexer.Lexer;
import lexer.Token;
import parser.Parser;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        // 从文件读入指令
        Lexer lexer = new Lexer();
        lexer.getCommands();
        /*for (int i = 0; i < 10; i++) {
            Token token = lexer.scan();
            System.out.println(token.toString());
        }*/
        Parser parser = new Parser(lexer);
        parser.program();
    }
}
