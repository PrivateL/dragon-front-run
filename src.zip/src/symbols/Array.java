package symbols;
import lexer.*;

import java.util.ArrayList;

public class Array extends Type {
   public Type of;                  // array *of* type
   public int size = 1;             // number of elements
   private ArrayList<Token> value;
   public Array(int sz, Type p) {
      super("[]", Tag.INDEX, sz*p.width); size = sz;  of = p;
      value = new ArrayList<>();
         for (int i = 0; i < size; i++) {
            if(of==Type.Int || of==Type.Char){
               value.add(new Num(0));
            }else if(of==Type.Float){
               value.add(new Real(0.0f));
            }
         }
   }
   public String toString() { return "[" + size + "] " + of.toString(); }
}
